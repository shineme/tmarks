import './assets/index.ts-CaDA-j3G.js';
